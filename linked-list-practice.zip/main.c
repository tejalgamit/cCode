
/**
1. MAKE DATABASE OF 10 ITEMS. WAREHOUSE
2. GENERATE BILLS
3. UPDATE WAREHOUSE AFTER EACH BILL /SALE
3. AT THE END OF DAY , UPDATE WAREHOUSE STOCK
**/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
struct item
{
    //hsncode; how long? 20 char
    //char sHsnCode[20]
    //product disctiption
    char sDiscription[50];
    //mrp
    float fMrp;
    //quntity
    int quantity;
    struct item* next;
};

struct item* head = NULL;
struct item* tail = NULL;
//add item
void addItem(struct item* newItem)
{
    
    
}

void updateItem(struct item* updateItem)
{
    
    
}

//update warehouse
void updateStock(void)
{
    
    
}

//update wareHouse at the EOD = End Of the Day
void updateWareHouseAtEOD(void)
{
    
    
}

void showDiscription(struct* item)
{
    //display discription
    
}

void getCurrentTime()
{
    time_t time1;
    struct tm * timeDetail;
    
    time(&time1);
    timeDetail = localtime(&timeDetail);
    
   /*[%d %d %d %d:%d:%d]", timeDetail->tm_mday,
            timeDetail->tm_mon + 1, timeDetail->tm_year + 1900,
            timeDetail->tm_hour, timeDetail->tm_min, timeDetail->tm_sec
            */
    
}

int main(void)
{
    FILE* fp;
    
    
    //1. MAKE DATABASE OF 10 ITEMS. WAREHOUSE
        //add 10 items in warehouse
                 
        // open fille
        fp = fopen("database.txt","w");
        if(fp == NULL)
        {
            printf("\nError file handling\n");
            return 1;
        }
        //add items in this file
        
        //close file
    /********BILLING and WAREHOUSE UPDATING LOOP****************************/    
    //open file to read 
    // get the current day using standard lib for time
    //loop for the day 
    
        //2. GENERATE BILL
        
            // 1.get hsncode from customer
                //show product discription
                //get the quntity
                
            //get how many types of items customer repear? 
                // for now it is 5 items  ; same function can be used for multipe bills  
            
                //generate bill of 5 ITEMS
            
        
                // update warehous 
    
        //3. AT THE END OF DAY , UPDATE WAREHOUSE STOCK
          
            //if it is time defined as end / closing time
            
                //update warehouse
    
}