/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>

float sum(int no1, int no2)
{
   
    return (no1 + no2) ;
    
}

int main()
{
   
 
   float Number1, Number2;
   float Ans;
   char Reply;
   
   do{
   
   printf("\n Enter Number1:");
   scanf("%f",&Number1);
   printf("\n Enter Number2:");
    scanf("%f",&Number2);
   
   Ans = sum(Number1,Number2);
   
   printf("\n %ld + %ld = %ld \n",(long int) Number1, (long int) Number2,(long int)Ans);
   
   printf("\nDo you want more:");
   scanf(" %c",&Reply);

   }while(Reply == 'y');
   printf("\nThank you... bye\n");

    return 0;
}